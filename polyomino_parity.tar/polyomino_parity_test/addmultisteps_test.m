function addmultisteps_test ( )

%*****************************************************************************80
%
%% addmultisteps_test() tests addmultisteps().
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    06 June 2020
%
%  Author:
%
%    Marcus Garvie,
%    John Burkardt
%
%  Reference:
%
%    Marcus Garvie, John Burkardt,
%    Checkerboard Colouring Arguments For Impossible Polyomino 
%    Tiling Problems,
%    In preparation.
%
  fprintf ( 1, '\n' );
  fprintf ( 1, 'addmultisteps_test():\n' );
  fprintf ( 1, '  MATLAB/Octave version %s\n', version ( ) );
  fprintf ( 1, '  [ num, no_sums, s ] = addmultisteps ( p, ns, steps )\n' );
  fprintf ( 1, '  input:\n' );
  fprintf ( 1, '    P is the parity of the region.\n' );
  fprintf ( 1, '    NS is a vector of step counts.\n' );
  fprintf ( 1, '    STEPS is a vector of step sizes.\n' );   
  fprintf ( 1, '  output:\n' );
  fprintf ( 1, '    NUM is the number of sums equal to P.\n' );
  fprintf ( 1, '    NO_SUMS is the number of sums generated.\n' );
  fprintf ( 1, '    S, contains every sum computed.\n' );

  for test = 1 : 3

    if ( test == 1 )
      p = 0;
      ns = [ 2, 5, 3, 6, 7 ];
      steps = [ 1, 3, 2, 5, 9 ];
      correct = 56;
    elseif ( test == 2 )
      p = 4;
      ns = [ 1, 1, 3 ];
      steps = [ 1, 3, 4 ];
      correct = 0;
    elseif ( test == 3 )
      p = 4;
      ns = [ 3, 1, 1 ];
      steps = [ 1, 3, 4 ];
      correct = 2;
    end

    n = length ( ns );

    fprintf ( 1, '\n' );
    fprintf ( 1, '  For this example:\n' );
    fprintf ( 1, '    P = %d\n', p );
    fprintf ( 1, '    NS = [' );
    for i = 1 : length ( ns )
      fprintf ( 1, ' %d', ns(i) );
      if ( i < n )
        fprintf ( 1, ',' );
      else
        fprintf ( 1, ' ]\n' );
      end
    end

    fprintf ( 1, '    STEPS = [' );
    for i = 1 : length ( steps )
      fprintf ( 1, ' %d', steps(i) );
      if ( i < n )
        fprintf ( 1, ',' );
      else
        fprintf ( 1, ' ]\n' );
      end
    end

    [ num, no_sums, s ] = addmultisteps ( p, ns, steps );

    fprintf ( 1, '\n' );
    fprintf ( 1, '  %d sums equal to P were found:\n', num );
    fprintf ( 1, '  Correct number of such sums is %d\n', correct );
    fprintf ( 1, '  %d sums were generated:\n', no_sums );

  end

  return
end

