function diophantine_nd_nonnegative_test ( )

%*****************************************************************************80
%
%% diophantine_nd_nonnegative_test() tests diophantine_nd_nonnegative().
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    19 May 2020
%
%  Author:
%
%    John Burkardt
%
  fprintf ( 1, '\n' );
  fprintf ( 1, 'diophantine_nd_nonnegative_test()\n' );
  fprintf ( 1, '  MATLAB/Octave version %s\n', version ( ) );
  fprintf ( 1, '  diophantine_nd_nonnegative() returns nonnegative solutions\n' );
  fprintf ( 1, '  of a Diophantine equation in N variables.\n' );

  a = [ 2; 3 ];
  b = 18;
  fprintf ( 1, '\n' );
  if ( diophantine_nd_check ( a, b ) )
    diophantine_equation_print ( a, b );
    x = diophantine_nd_nonnegative ( a, b );
    diophantine_solution_print ( a, b, x );
  end

  a = [ 6; 3; 13 ];
  b = 16;
  fprintf ( 1, '\n' );
  if ( diophantine_nd_check ( a, b ) )
    diophantine_equation_print ( a, b );
    x = diophantine_nd_nonnegative ( a, b );
    diophantine_solution_print ( a, b, x );
  end

  a = [ 12; 9; 7 ];
  b = 60;
  fprintf ( 1, '\n' );
  if ( diophantine_nd_check ( a, b ) )
    diophantine_equation_print ( a, b );
    x = diophantine_nd_nonnegative ( a, b );
    diophantine_solution_print ( a, b, x );
  end

  a = [ 2; 3; 5; 6 ];
  b = 24;
  fprintf ( 1, '\n' );
  if ( diophantine_nd_check ( a, b ) )
    diophantine_equation_print ( a, b );
    x = diophantine_nd_nonnegative ( a, b );
    diophantine_solution_print ( a, b, x );
  end

  a = [ 2; 3; 5; 6; 7 ];
  b = 35;
  fprintf ( 1, '\n' );
  if ( diophantine_nd_check ( a, b ) )
    diophantine_equation_print ( a, b );
    x = diophantine_nd_nonnegative ( a, b );
    diophantine_solution_print ( a, b, x );
  end

  return
end

