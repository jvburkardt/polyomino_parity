function pv_search_test ( )

%*****************************************************************************80
%
%% pv_search_test() tests pv_search().
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    06 June 2020
%
%  Author:
%
%    Marcus Garvie,
%    John Burkardt
%
  fprintf ( 1, '\n' );
  fprintf ( 1, 'pv_search_test()\n' );
  fprintf ( 1, '  MATLAB/Octave version %s\n', version ( ) );
  fprintf ( 1, '  pv_search() applies parity arguments to potential\n' );
  fprintf ( 1, '  solutions of a polyomino tiling problem.\n' );

  for test = 1 : 3

    if ( test == 1 )
      label = '  Example 6';
      parities = [ 0, 1 ];
      orders = [ 4, 3 ];
      p = 9;
      c = 41;
    elseif ( test == 2 )
      label = '  Example 8';
      parities = [ 0, 2, 3, 5 ];
      orders = [ 2, 4, 5, 9 ];
      p = 0;
      c = 156;
    elseif ( test == 3 )
      label = '  Example 9';
      parities = [ 0, 1, 2, 5 ];
      orders = [ 4, 3, 6, 13 ];
      p = 0;
      c = 320;
    end

    n = length ( parities );

    fprintf ( 1, '\n' );
    fprintf ( 1, '%s\n', label );

    fprintf ( 1, '  parities = [' );
    for i = 1 : n
      fprintf ( 1, ' %d', parities(i) );
      if ( i < n )
        fprintf ( 1, ',' );
      else
        fprintf ( 1, ' ]\n' );
      end
    end

    fprintf ( 1, '  orders = [' );
    for i = 1 : n
      fprintf ( 1, ' %d', orders(i) );
      if ( i < n )
        fprintf ( 1, ',' );
      else
        fprintf ( 1, ' ]\n' );
      end
    end

    fprintf ( 1, '  p = %d\n', p );

    fprintf ( 1, '  c = %d\n', c );
%
%  Search for parity violations.
%
    [ S1, S2 ] = pv_search ( parities, orders, p, c );
%
%  Report results.
%
    pv_search_post ( S1, S2 );

  end
%
%  Terminate.
%
  fprintf ( 1, '\n' );
  fprintf ( 1, 'pv_search_test():\n' );
  fprintf ( 1, '  Normal end of execution.\n' );

  return
end

