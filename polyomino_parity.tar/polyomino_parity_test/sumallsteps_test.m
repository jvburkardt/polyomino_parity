function sumallsteps_test ( )

%*****************************************************************************80
%
%% sumallsteps_test() tests sumallsteps().
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    19 June 2020
%
%  Author:
%
%    Marcus Garvie,
%    John Burkardt
%
%  Reference:
%
%    Marcus Garvie, John Burkardt,
%    Checkerboard Colouring Arguments For Impossible Polyomino 
%    Tiling Problems,
%    In preparation.
%
  fprintf ( 1, '\n' );
  fprintf ( 1, 'sumallsteps_test():\n' );
  fprintf ( 1, '  MATLAB/Octave version %s\n', version ( ) );
  fprintf ( 1, '  sumallsteps() finds all possible sums, of the form\n' );
  fprintf ( 1, '    S = Ai + N * ( +/- Q )\n' );
  fprintf ( 1, '  where:\n' );
  fprintf ( 1, '    Ai is any single entry of the vector A\n' );
  fprintf ( 1, '    N counts the number of +/- Q values to be added.\n' );
  fprintf ( 1, '    Q is the magnitude of the increments or steps.\n' );
%
%  Example from paper.
%  Correct result:
%    S_num = 18
%    S = [ -15, -14, -11, -10, -7, -6, -3, -2, 1, 2, 5, 6, 9, 10, 13, 14, 17, 18 ].
%
  A = [ 1, 2 ];
  N = 8;
  Q = 2;

  fprintf ( 1, '\n' );
  fprintf ( 1, '  For this example:\n' );
  fprintf ( 1, '    A = [' );
  for i = 1 : length ( A )
    fprintf ( 1, ' %d', A(i) );
    if ( i < length ( A ) )
      fprintf ( 1, ',' );
    else
      fprintf ( 1, ' ]\n' );
    end
  end
  fprintf ( 1, '    N = %d\n', N );
  fprintf ( 1, '    Q = %d\n', Q );

  S = sumallsteps ( A, N, Q );

  S_num = length ( S );
  fprintf ( 1, '\n' );
  fprintf ( 1, '  %d distinct sums were found:\n', S_num );
  fprintf ( 1, '\n' );
  for i = 1 : S_num
    fprintf ( 1, '  %2d: %3d\n', i, S(i) );
  end

  return
end

