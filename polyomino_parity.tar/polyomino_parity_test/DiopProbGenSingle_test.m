function DiopProbGenSingle_test ( )

%*****************************************************************************80
%
%% DiopProbGenSingle_test tests DiopProbGenSingle().
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    19 June 2020
%
%  Author:
%
%    Marcus Garvie,
%    John Burkardt
%
%  Reference:
%
%    Marcus Garvie, John Burkardt,
%    Checkerboard Colouring Arguments For Impossible Polyomino 
%    Tiling Problems,
%    In preparation.
%
  fprintf ( 1, '\n' );
  fprintf ( 1, 'DiopProbGenSingle_test():\n' );
  fprintf ( 1, '  Test DiopProbGenSingle()\n' );
%
%  Example 8 in the paper.
%
  fprintf ( 1, 'Example 8\n' );
  parities = [0,2,3,5];
  orders = [2,4,5,9];
  p = 0;
  c = 156;
  DiopProbGenSingle ( parities, orders, p, c );
%
%  Example 9 in the paper.
%
  fprintf ( 1, 'Example 9\n' );
  parities = [0,1,2,5];
  orders = [ 4,3,6,13];
  p = 0;
  c = 320;
  DiopProbGenSingle ( parities, orders, p, c );

  return
end

